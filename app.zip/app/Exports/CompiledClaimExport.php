<?php

namespace App\Exports;

use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\WithHeadings;

class CompiledClaimExport implements FromArray, WithHeadings
{
    protected $data;

    public function __construct($data)
    {
        $this->data = $data;
    }
    private $statusMap = [
        1 => 'Waiting For Regional Manager Approval',
        2 => 'Rejected By Area Supervisor',
        4 => 'Waiting for Agent Approval',
        5 => 'Rejected By Agent',
        6 => 'Awaiting Data Analyst Verification',
        7 => 'Rejected By Regional Manager',
        8 => 'Completed',
        9 => 'Rejected',
    ];

    public function headings(): array
    {
        return [
            "Code",
            "Claim Period",
            "warehouse",
            // "Approved Claims (Count)",
            "Approved Qty(CSE)",
            "Approved Claim Amount",
            "Rejected Qty(CSE)",
            "Rejected Amount
",
            "regional_sales_manager",
            "month_range",
            "promo_count",
            "promo_qty",
            "promo_amount",
            "agent_id",
            "asm_actiondate",
            "status",
        ];
    }

    public function array(): array
    {
        return $this->data->map(function ($item) {
            return [
                $item->osa_code,
                $item->month_range,
                trim(
                    (optional($item->warehouse)->warehouse_code ?? '') .
                        ' - ' .
                        (optional($item->warehouse)->warehouse_name ?? ''),
                    ' -'
                ),
                $item->approved_qty_cse,
                $item->approved_claim_amount,
                $item->rejected_qty_cse,
                $item->rejected_amount,
                $item->area_sales_supervisor,
                $item->regional_sales_manager,
                $item->agent_id,
                $this->statusMap[$item->status] ?? 'Unknown',
            ];
        })->toArray();
    }
}
